package GUI;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;


public class AddAccount extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public AddAccount() {
		setTitle("Add Account");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(400, 300);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setBackground(new Color(52, 73, 94));
		contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
		contentPane.setLayout(new BorderLayout(20, 20));
		setContentPane(contentPane);

		JLabel lblAddAccount = new JLabel("Add Account", SwingConstants.CENTER);
		lblAddAccount.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblAddAccount.setForeground(new Color(241, 196, 15));
		contentPane.add(lblAddAccount, BorderLayout.NORTH);

		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(new Color(44, 62, 80));
		buttonPanel.setLayout(new GridLayout(3, 1, 15, 15));
		contentPane.add(buttonPanel, BorderLayout.CENTER);

		JButton btnSavings = createButton("Add Saving Account", new Color(46, 204, 113));
		btnSavings.addActionListener(e -> openForm(GUIForm.addsavingsaccount));
		buttonPanel.add(btnSavings);

		JButton btnCurrent = createButton("Add Current Account", new Color(52, 152, 219));
		btnCurrent.addActionListener(e -> openForm(GUIForm.addcurrentacc));
		buttonPanel.add(btnCurrent);

		JButton btnStudent = createButton("Add Student Account", new Color(155, 89, 182));
		btnStudent.addActionListener(e -> openForm(GUIForm.addstudentaccount));
		buttonPanel.add(btnStudent);
	}

	private JButton createButton(String text, Color bgColor) {
		JButton button = new JButton(text);
		button.setBackground(bgColor);
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Tahoma", Font.BOLD, 14));
		button.setFocusPainted(false);
		return button;
	}

	private void openForm(JFrame form) {
		if (!form.isVisible()) {
			form.setVisible(true);
			dispose();
		} else {
			JOptionPane.showMessageDialog(this, "Already Opened", "Warning", JOptionPane.WARNING_MESSAGE);
		}
	}
}
