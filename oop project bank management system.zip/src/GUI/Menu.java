package GUI;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Data.FileIO;

public class Menu extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public Menu() {
		setTitle("Banking System");
		setSize(700, 500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		contentPane = new JPanel();
		contentPane.setBackground(new Color(44, 62, 80)); // Matching background color
		contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
		contentPane.setLayout(new BorderLayout(20, 20));
		setContentPane(contentPane);

		// Title
		JLabel lblBankingSystem = new JLabel("Banking System", SwingConstants.CENTER);
		lblBankingSystem.setFont(new Font("Tahoma", Font.BOLD, 28)); // Matching font
		lblBankingSystem.setForeground(new Color(241, 196, 15)); // Matching title color
		contentPane.add(lblBankingSystem, BorderLayout.NORTH);

		// Buttons panel
		JPanel buttonPanel = new JPanel();
		buttonPanel.setBackground(new Color(44, 62, 80)); // Matching background color
		buttonPanel.setLayout(new GridLayout(5, 1, 15, 15));
		contentPane.add(buttonPanel, BorderLayout.CENTER);

		JButton btnAddAccount = createButton("Add Account", new Color(52, 152, 219)); // Matching button color
		btnAddAccount.addActionListener(e -> openWindow(GUIForm.addaccount));
		buttonPanel.add(btnAddAccount);

		JButton btnDeposit = createButton("Deposit To Account", new Color(46, 204, 113)); // Matching button color
		btnDeposit.addActionListener(e -> openWindow(GUIForm.depositacc));
		buttonPanel.add(btnDeposit);

		JButton btnWithdraw = createButton("Withdraw From Account", new Color(230, 126, 34)); // Matching button color
		btnWithdraw.addActionListener(e -> openWindow(GUIForm.withdraw));
		buttonPanel.add(btnWithdraw);

		JButton btnDisplayList = createButton("Display Account List", new Color(155, 89, 182)); // Matching button color
		btnDisplayList.addActionListener(e -> openWindow(GUIForm.displaylist));
		buttonPanel.add(btnDisplayList);

		JButton btnExit = createButton("Exit", new Color(231, 76, 60)); // Matching button color
		btnExit.addActionListener(e -> {
			JOptionPane.showMessageDialog(this, "Thanks For Using");
			FileIO.Write();
			System.exit(0);
		});
		buttonPanel.add(btnExit);

		// Image Panel
		JLabel imageLabel = new JLabel();
		imageLabel.setIcon(new ImageIcon(Menu.class.getResource("/img/1.png")));
		imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(imageLabel, BorderLayout.EAST);

		// Load file
		FileIO.Read();
	}

	private JButton createButton(String text, Color bgColor) {
		JButton button = new JButton(text);
		button.setBackground(bgColor);
		button.setForeground(Color.WHITE);
		button.setFocusPainted(false);
		button.setFont(new Font("Tahoma", Font.BOLD, 14)); // Matching button font
		return button;
	}

	private void openWindow(JFrame window) {
		if (!window.isVisible()) {
			window.setVisible(true);
		} else {
			JOptionPane.showMessageDialog(this, "Already Opened", "Warning", JOptionPane.WARNING_MESSAGE);
		}
	}
}
