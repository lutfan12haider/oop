package GUI;

import Data.FileIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;

public class AddStudentAccount extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField nameField;
	private JTextField balanceField;
	private JTextField institutionName;

	public AddStudentAccount() {
		setTitle("Add Student Account");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(450, 320);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setBackground(new Color(44, 62, 80));
		contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
		contentPane.setLayout(new BorderLayout(20, 20));
		setContentPane(contentPane);

		JLabel titleLabel = new JLabel("Add Student Account", SwingConstants.CENTER);
		titleLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		titleLabel.setForeground(new Color(241, 196, 15));
		contentPane.add(titleLabel, BorderLayout.NORTH);

		JPanel formPanel = new JPanel(new GridLayout(3, 2, 15, 15));
		formPanel.setBackground(new Color(44, 62, 80));
		contentPane.add(formPanel, BorderLayout.CENTER);

		JLabel nameLabel = createLabel("Name:");
		nameField = createTextField();
		formPanel.add(nameLabel);
		formPanel.add(nameField);

		JLabel balanceLabel = createLabel("Balance:");
		balanceField = createTextField();
		formPanel.add(balanceLabel);
		formPanel.add(balanceField);

		JLabel licenseLabel = createLabel("Institute name:");
		institutionName = createTextField();
		formPanel.add(licenseLabel);
		formPanel.add(institutionName);

		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 10));
		buttonPanel.setBackground(new Color(44, 62, 80));
		contentPane.add(buttonPanel, BorderLayout.SOUTH);

		JButton addBtn = createButton("Add", new Color(46, 204, 113));
		addBtn.addActionListener(this::handleAdd);
		buttonPanel.add(addBtn);

		JButton resetBtn = createButton("Reset", new Color(231, 76, 60));
		resetBtn.addActionListener(e -> resetFields());
		buttonPanel.add(resetBtn);
	}

	private JLabel createLabel(String text) {
		JLabel label = new JLabel(text);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Tahoma", Font.PLAIN, 13));
		return label;
	}

	private JTextField createTextField() {
		JTextField field = new JTextField();
		field.setFont(new Font("Tahoma", Font.PLAIN, 13));
		return field;
	}

	private JButton createButton(String text, Color bg) {
		JButton button = new JButton(text);
		button.setBackground(bg);
		button.setForeground(Color.WHITE);
		button.setFocusPainted(false);
		button.setFont(new Font("Tahoma", Font.BOLD, 13));
		return button;
	}

	private void resetFields() {
		nameField.setText("");
		balanceField.setText("");
		institutionName.setText("");
	}

	private void handleAdd(ActionEvent e) {
		String name = nameField.getText().trim();
		String balStr = balanceField.getText().trim();
		String license = institutionName.getText().trim();

		if (name.isEmpty() || balStr.isEmpty() || license.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please fill all fields!", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}

		double balance;
		try {
			balance = Double.parseDouble(balStr);
		} catch (NumberFormatException ex) {
			JOptionPane.showMessageDialog(this, "Invalid balance amount!", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}

		if (balance < 5000) {
			JOptionPane.showMessageDialog(this, "Minimum balance should be 5000!", "Warning", JOptionPane.WARNING_MESSAGE);
			resetFields();
			return;
		}

		int confirm = JOptionPane.showConfirmDialog(this, "Confirm adding this account?", "Confirm", JOptionPane.YES_NO_OPTION);
		if (confirm == JOptionPane.YES_OPTION) {
			try {
				int index = FileIO.bank.addAccount(name, balance, license);
				DisplayList.arr.addElement(FileIO.bank.getAccounts()[index].toString());
				JOptionPane.showMessageDialog(this, "Account added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
				dispose();
			} catch (Exception ex) {
				ex.printStackTrace();
				JOptionPane.showMessageDialog(this, "Error occurred while adding account.", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}
