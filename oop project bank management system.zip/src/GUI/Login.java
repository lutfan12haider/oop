package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login {

	public JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				Login window = new Login();
				window.frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public Login() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame("Banking System");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 300);
		frame.setLocationRelativeTo(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(44, 62, 80)); // Matching background color
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
		frame.setContentPane(panel);

		JLabel title = new JLabel("Banking System");
		title.setFont(new Font("Tahoma", Font.BOLD, 22)); // Matching font
		title.setForeground(new Color(241, 196, 15)); // Matching font color
		title.setAlignmentX(Component.CENTER_ALIGNMENT);
		panel.add(title);

		panel.add(Box.createVerticalStrut(10));

		JLabel loginLabel = new JLabel("LOGIN SCREEN");
		loginLabel.setFont(new Font("Tahoma", Font.BOLD, 14)); // Matching font
		loginLabel.setForeground(Color.WHITE);
		loginLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		panel.add(loginLabel);

		panel.add(Box.createVerticalStrut(20));

		JLabel userLabel = new JLabel("Username:");
		userLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		userLabel.setForeground(Color.WHITE);
		userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(userLabel);

		textField = new JTextField("admin");
		textField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
		textField.setBackground(new Color(200, 200, 220));
		panel.add(textField);

		panel.add(Box.createVerticalStrut(10));

		JLabel passLabel = new JLabel("Password:");
		passLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		passLabel.setForeground(Color.WHITE);
		passLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel.add(passLabel);

		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
		passwordField.setBackground(new Color(200, 200, 220));
		panel.add(passwordField);

		panel.add(Box.createVerticalStrut(20));

		JButton loginButton = new JButton("Login");
		loginButton.setBackground(new Color(39, 174, 96)); // Matching button color
		loginButton.setForeground(Color.WHITE);
		loginButton.setFont(new Font("Tahoma", Font.BOLD, 14)); // Matching button font
		loginButton.setFocusPainted(false);
		loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String user = textField.getText().trim();
				String pass = new String(passwordField.getPassword()).trim();
				if (user.equals("admin") && pass.equals("admin")) {
					JOptionPane.showMessageDialog(frame, "Login Successful!");
					frame.setVisible(false);
					GUIForm.menu.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(frame, "Login Failed. Try again.");
				}
			}
		});
		panel.add(loginButton);
	}
}
